#!/usr/bin/env node
/**
 * SiteDeck Portfolio — Enterprise Client Provisioning Script
 * Client: Orion Fiber Solutions
 * Access Level: Enterprise (All Products)
 * Products: SiteDeck PM + SiteDeck Benchmark + SiteDeck Pro
 *
 * Run: node provision-orion-fiber.js
 * Requires: FIREBASE_SERVICE_ACCOUNT_KEY in .env (or set env directly)
 *
 * What this script does:
 *   1. Verifies / sets your super admin claims (support@sitedeck.pro)
 *   2. Creates Orion Fiber Solutions users with full enterprise claims
 *   3. Outputs a summary log you can paste into your onboarding notes
 */

require('dotenv').config();
const admin = require('firebase-admin');

// ─── Firebase Init ────────────────────────────────────────────────────────────
let serviceAccount;
try {
  serviceAccount = JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT_KEY);
} catch (e) {
  console.error('❌  FIREBASE_SERVICE_ACCOUNT_KEY not found or invalid in .env');
  process.exit(1);
}

if (!admin.apps.length) {
  admin.initializeApp({
    credential: admin.credential.cert(serviceAccount),
  });
}

const auth = admin.auth();

// ─── Configuration ────────────────────────────────────────────────────────────

const ORG_ID = 'orion-fiber-solutions';
const ORG_NAME = 'Orion Fiber Solutions';
const PLAN = 'enterprise';

// Your super admin account — never loses access regardless of org changes
const SUPER_ADMIN = {
  email: 'support@sitedeck.pro',
  claims: {
    role: 'owner_admin',
    super_admin: true,          // Platform-level flag — survives org scoping
    orgId: 'sitedeck-llc',
    plan: 'enterprise',
    // Access all three products
    products: ['pm', 'benchmark', 'pro'],
  },
};

// Orion Fiber Solutions users to provision
// Add as many contacts as you have — at minimum add their primary admin
const ORION_USERS = [
  {
    // Primary org admin — whoever manages their account
    email: 'admin@orionfiber.com',           // ← UPDATE to actual email
    displayName: 'Orion Admin',               // ← UPDATE to actual name
    claims: {
      role: 'owner_admin',
      orgId: ORG_ID,
      plan: PLAN,
      products: ['pm', 'benchmark', 'pro'],
      // PM access
      pm_access: true,
      // Benchmark access — full QC suite
      benchmark_access: true,
      // Pro field access
      pro_access: true,
    },
  },
  // Add more users here as needed:
  // {
  //   email: 'pm@orionfiber.com',
  //   displayName: 'Orion PM',
  //   claims: {
  //     role: 'project_manager',
  //     orgId: ORG_ID,
  //     plan: PLAN,
  //     products: ['pm', 'benchmark'],
  //     pm_access: true,
  //     benchmark_access: true,
  //   },
  // },
];

// ─── Helpers ──────────────────────────────────────────────────────────────────

async function getOrCreateUser(email, displayName) {
  try {
    const user = await auth.getUserByEmail(email);
    console.log(`  ✓ Found existing user: ${email} (${user.uid})`);
    return { user, created: false };
  } catch (err) {
    if (err.code === 'auth/user-not-found') {
      const newUser = await auth.createUser({
        email,
        displayName: displayName || email,
        emailVerified: true,
      });
      console.log(`  ✚ Created new user: ${email} (${newUser.uid})`);
      return { user: newUser, created: true };
    }
    throw err;
  }
}

async function setClaimsAndLog(uid, email, claims) {
  await auth.setCustomUserClaims(uid, claims);
  const verified = await auth.getUser(uid);
  const actual = verified.customClaims || {};
  const match = JSON.stringify(actual) === JSON.stringify(claims);
  if (match) {
    console.log(`  ✓ Claims verified on ${email}`);
  } else {
    console.warn(`  ⚠ Claims mismatch on ${email}`);
    console.warn(`    Expected: ${JSON.stringify(claims)}`);
    console.warn(`    Got:      ${JSON.stringify(actual)}`);
  }
  return actual;
}

// ─── Main ─────────────────────────────────────────────────────────────────────

async function main() {
  const log = [];
  const ts = new Date().toISOString();
  console.log('\n══════════════════════════════════════════════════════════════');
  console.log('  SiteDeck — Enterprise Client Provisioning');
  console.log(`  Client: ${ORG_NAME}`);
  console.log(`  Time:   ${ts}`);
  console.log('══════════════════════════════════════════════════════════════\n');

  // ── Step 1: Lock in super admin ─────────────────────────────────────────
  console.log('▶ Step 1: Verifying super admin (support@sitedeck.pro)');
  const { user: superUser } = await getOrCreateUser(
    SUPER_ADMIN.email,
    'SiteDeck Admin'
  );
  const superClaims = await setClaimsAndLog(
    superUser.uid,
    SUPER_ADMIN.email,
    SUPER_ADMIN.claims
  );
  log.push({
    type: 'super_admin',
    email: SUPER_ADMIN.email,
    uid: superUser.uid,
    claims: superClaims,
  });
  console.log('');

  // ── Step 2: Provision Orion Fiber Solutions users ───────────────────────
  console.log(`▶ Step 2: Provisioning ${ORG_NAME} users`);
  for (const u of ORION_USERS) {
    console.log(`\n  Processing: ${u.email}`);
    const { user, created } = await getOrCreateUser(u.email, u.displayName);
    const claims = await setClaimsAndLog(user.uid, u.email, u.claims);

    log.push({
      type: created ? 'created' : 'updated',
      org: ORG_NAME,
      email: u.email,
      displayName: u.displayName,
      uid: user.uid,
      claims,
    });
  }

  // ── Step 3: Summary output ──────────────────────────────────────────────
  console.log('\n══════════════════════════════════════════════════════════════');
  console.log('  PROVISIONING COMPLETE — Paste this into your onboarding notes');
  console.log('══════════════════════════════════════════════════════════════\n');
  console.log(`Client:    ${ORG_NAME}`);
  console.log(`Org ID:    ${ORG_ID}`);
  console.log(`Plan:      ${PLAN}`);
  console.log(`Timestamp: ${ts}`);
  console.log('\nUsers provisioned:');
  for (const entry of log) {
    if (entry.type === 'super_admin') {
      console.log(`  [SUPER ADMIN] ${entry.email} — uid: ${entry.uid}`);
    } else {
      console.log(`  [${entry.type.toUpperCase()}] ${entry.email} — uid: ${entry.uid} — role: ${entry.claims.role}`);
    }
  }

  console.log('\n⚠  Next steps:');
  console.log('   1. Send Orion admin their invite/password reset link via Firebase Console');
  console.log('      (Auth → Users → find their email → Send password reset)');
  console.log('   2. Verify they can log into all three products:');
  console.log('      PM:        projects.sitedeck.pro');
  console.log('      Benchmark: benchmark.sitedeck.pro');
  console.log('      Pro:       (iOS/Android app)');
  console.log('   3. Confirm your own login still has super_admin: true in claims');
  console.log('      (Firebase Console → Auth → find support@sitedeck.pro → Custom claims)');
  console.log('');
}

main().catch((err) => {
  console.error('\n❌  Script failed:', err.message);
  process.exit(1);
});
