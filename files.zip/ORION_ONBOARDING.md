# Orion Fiber Solutions — Enterprise Provisioning

## What This Does

Provisions **Orion Fiber Solutions** with full enterprise access across:
- ✅ SiteDeck PM (`projects.sitedeck.pro`)
- ✅ SiteDeck Benchmark (`benchmark.sitedeck.pro`)
- ✅ SiteDeck Pro (iOS/Android)

And **locks in your super admin** (`support@sitedeck.pro`) with a `super_admin: true` 
claim that sits above org-level scoping so you always retain full access.

---

## Before You Run

### 1. Update the Orion user emails

Open `provision-orion-fiber.js` and find the `ORION_USERS` array.
Replace the placeholder:

```js
email: 'admin@orionfiber.com',    // ← their real email
displayName: 'Orion Admin',       // ← their real name
```

Add more users to the array if you're onboarding multiple people at once.

### 2. Make sure your .env has the service account key

```
FIREBASE_SERVICE_ACCOUNT_KEY={"type":"service_account","project_id":"..."}
```

This is the same key used by your PM and Benchmark backends on the VPS.
Copy it from your `.env` on the VPS if you don't have it locally.

---

## Run It

```bash
# From the SiteDeckPM repo root (or wherever firebase-admin is installed)
npm install firebase-admin dotenv   # if not already installed
node provision-orion-fiber.js
```

---

## After Running

1. **Send Orion their password reset link**
   Firebase Console → Authentication → Users → find their email → "Send password reset email"
   (Or use the Firebase Admin SDK to generate a link if you want to customize the email)

2. **Verify their access** by logging in as them (or asking them to confirm) at:
   - `projects.sitedeck.pro`
   - `benchmark.sitedeck.pro`
   - SiteDeck Pro mobile app

3. **Check your own claims** haven't been overwritten:
   Firebase Console → Authentication → find `support@sitedeck.pro` → look for `super_admin: true`

---

## Claims Reference

### Your account (support@sitedeck.pro)
```json
{
  "role": "owner_admin",
  "super_admin": true,
  "orgId": "sitedeck-llc",
  "plan": "enterprise",
  "products": ["pm", "benchmark", "pro"]
}
```

### Orion admin account
```json
{
  "role": "owner_admin",
  "orgId": "orion-fiber-solutions",
  "plan": "enterprise",
  "products": ["pm", "benchmark", "pro"],
  "pm_access": true,
  "benchmark_access": true,
  "pro_access": true
}
```

---

## If You Need to Add More Orion Users Later

Add entries to `ORION_USERS` and re-run. The script is idempotent — it won't 
duplicate users, it'll just update their claims.

Role options for additional users:
- `owner_admin` — full access, can manage org settings
- `project_manager` — PM + Benchmark read/manage, Pro read
- `superintendent` — Pro field + PM view
- `qc_manager` — Benchmark full access
- `qc_inspector` — Benchmark inspections
- `third_party_inspector` — Benchmark inspector portal only
